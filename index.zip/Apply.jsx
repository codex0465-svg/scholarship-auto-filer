import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { UploadCloud, FileText, CheckCircle2, XCircle, Sparkles, Send, ArrowRight, Info, AlertTriangle } from 'lucide-react';

export default function Apply() {
  const { user, token, demoLoginStudent } = useAuth();
  const navigate = useNavigate();

  // Step state: 1: Documents & Extraction, 2: Eligibility & Review Form
  const [step, setStep] = useState(1);

  // Form Fields
  const [courseLevel, setCourseLevel] = useState('PhD');

  // Documents extractions state
  const [extractions, setExtractions] = useState({
    caste: null,
    marksheet: null,
    income: null,
    bank_passbook: null
  });

  const [loadingExtract, setLoadingExtract] = useState({
    caste: false,
    marksheet: false,
    income: false,
    bank_passbook: false
  });

  // Eligibility Evaluation Result
  const [eligibilityResult, setEligibilityResult] = useState(null);
  const [loadingEligibility, setLoadingEligibility] = useState(false);

  // Auto-filled Form State (Editable)
  const [formData, setFormData] = useState({
    scheme_id: '',
    applicant_name: '',
    category: 'ST',
    course_level: 'PhD',
    annual_income: '210000',
    marks_percentage: '68.5',
    certificate_number: '',
    account_number: '',
    ifsc_code: '',
    bank_name: ''
  });

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  // Auto login student if not logged in when visiting apply page
  useEffect(() => {
    if (!user) {
      demoLoginStudent();
    }
  }, [user]);

  // Update formData when extractions change
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      applicant_name: extractions.caste?.name || extractions.marksheet?.name || prev.applicant_name || user?.full_name || 'Rahul Kumar Marandi',
      category: extractions.caste?.category || 'ST',
      course_level: courseLevel,
      annual_income: extractions.income?.annual_income_inr?.toString() || prev.annual_income || '210000',
      marks_percentage: extractions.marksheet?.marks_percentage?.toString() || prev.marks_percentage || '68.5',
      certificate_number: extractions.caste?.certificate_number || prev.certificate_number || 'ST-JH-2024-88912',
      account_number: extractions.bank_passbook?.account_number || prev.account_number || '987654321012',
      ifsc_code: extractions.bank_passbook?.ifsc_code || prev.ifsc_code || 'SBIN0001234',
      bank_name: extractions.bank_passbook?.bank_name || prev.bank_name || 'State Bank of India'
    }));
  }, [extractions, courseLevel, user]);

  // Handle document upload or preset extraction
  const handleExtractDocument = async (docType, file = null) => {
    setLoadingExtract(prev => ({ ...prev, [docType]: true }));

    try {
      const data = new FormData();
      data.append('document_type', docType);
      if (file) {
        data.append('document', file);
      } else {
        data.append('preset_sample', 'true');
      }

      const currentToken = token || localStorage.getItem('scholarship_token');

      const res = await fetch('http://localhost:5000/api/extract', {
        method: 'POST',
        headers: { Authorization: `Bearer ${currentToken}` },
        body: data
      });

      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Extraction failed');

      setExtractions(prev => ({
        ...prev,
        [docType]: result.extracted_data
      }));
    } catch (err) {
      console.error(`Extract ${docType} error:`, err);
      alert(`Failed to extract ${docType}: ` + err.message);
    } finally {
      setLoadingExtract(prev => ({ ...prev, [docType]: false }));
    }
  };

  // Run Eligibility Prediction
  const runEligibilityCheck = async () => {
    setLoadingEligibility(true);
    try {
      const currentToken = token || localStorage.getItem('scholarship_token');
      const payload = {
        category: formData.category || 'ST',
        course_level: courseLevel,
        annual_income: parseFloat(formData.annual_income) || 210000,
        marks_percentage: parseFloat(formData.marks_percentage) || 68.5
      };

      const res = await fetch('http://localhost:5000/api/eligibility', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentToken}`
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Eligibility check failed');

      setEligibilityResult(data);

      // Default to first eligible scheme if available
      if (data.eligible_schemes?.length > 0) {
        setFormData(prev => ({ ...prev, scheme_id: data.eligible_schemes[0].id.toString() }));
      }

      setStep(2);
    } catch (err) {
      console.error('Eligibility check error:', err);
      alert('Eligibility check failed: ' + err.message);
    } finally {
      setLoadingEligibility(false);
    }
  };

  // Submit Application
  const handleSubmitApplication = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setSubmitError('');

    if (!formData.scheme_id) {
      setSubmitError('Please select a scholarship scheme to apply for.');
      setSubmitting(false);
      return;
    }

    try {
      const currentToken = token || localStorage.getItem('scholarship_token');
      const res = await fetch('http://localhost:5000/api/applications', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentToken}`
        },
        body: JSON.stringify(formData)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to submit application.');

      alert(`Success! Application submitted for ${data.scheme_name}. ID: #${data.application_id}`);
      navigate('/my-applications');
    } catch (err) {
      console.error('Submit application error:', err);
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
      {/* Header Banner */}
      <div style={{ backgroundColor: '#ffffff', padding: '24px', borderRadius: 'var(--radius-md)', border: '1px solid var(--slate-border)', marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--primary-navy)' }}>
            ST Scholarship Auto-Filer Wizard
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--slate-medium)' }}>
            Upload documents, verify Gemini AI extractions, view scheme eligibility, and submit.
          </p>
        </div>

        {/* Step Indicator */}
        <div style={{ display: 'flex', gap: '8px' }}>
          <div style={{ padding: '6px 14px', borderRadius: '20px', fontSize: '13px', fontWeight: 700, backgroundColor: step === 1 ? 'var(--primary-navy)' : 'var(--slate-border)', color: step === 1 ? '#fff' : 'var(--slate-medium)' }}>
            1. Upload & Extract
          </div>
          <div style={{ padding: '6px 14px', borderRadius: '20px', fontSize: '13px', fontWeight: 700, backgroundColor: step === 2 ? 'var(--primary-navy)' : 'var(--slate-border)', color: step === 2 ? '#fff' : 'var(--slate-medium)' }}>
            2. Match & Submit
          </div>
        </div>
      </div>

      {step === 1 && (
        <div>
          {/* Course Level Selection */}
          <div className="card" style={{ marginBottom: '24px' }}>
            <label style={{ display: 'block', fontSize: '15px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '8px' }}>
              Select Your Pursuing Course Level:
            </label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
              {['UG', 'PG', 'Masters', 'MPhil', 'PhD'].map(lvl => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setCourseLevel(lvl)}
                  style={{
                    padding: '10px 20px',
                    borderRadius: '8px',
                    fontSize: '14px',
                    fontWeight: 700,
                    border: '2px solid',
                    borderColor: courseLevel === lvl ? 'var(--primary-navy)' : 'var(--slate-border)',
                    backgroundColor: courseLevel === lvl ? 'var(--primary-navy-light)' : '#ffffff',
                    color: courseLevel === lvl ? 'var(--primary-navy)' : 'var(--slate-medium)',
                    cursor: 'pointer'
                  }}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          {/* Document Upload & Extraction Cards */}
          <h2 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <UploadCloud size={20} /> Upload Eligibility Documents (AI Vision Extraction)
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(440px, 1fr))', gap: '20px', marginBottom: '24px' }}>
            {/* 1. Caste Certificate */}
            <DocumentUploadBox
              title="1. Caste Certificate (ST)"
              description="Verbatim extraction: name, category, certificate_number, issue_date"
              docType="caste"
              extraction={extractions.caste}
              loading={loadingExtract.caste}
              onExtract={(file) => handleExtractDocument('caste', file)}
            />

            {/* 2. Marksheet */}
            <DocumentUploadBox
              title="2. Marksheet / Transcript"
              description="Verbatim extraction: name, marks_percentage, year_of_passing, board_or_university"
              docType="marksheet"
              extraction={extractions.marksheet}
              loading={loadingExtract.marksheet}
              onExtract={(file) => handleExtractDocument('marksheet', file)}
            />

            {/* 3. Income Certificate */}
            <DocumentUploadBox
              title="3. Income Certificate"
              description="Verbatim extraction: name, annual_income_inr, financial_year"
              docType="income"
              extraction={extractions.income}
              loading={loadingExtract.income}
              onExtract={(file) => handleExtractDocument('income', file)}
            />

            {/* 4. Bank Passbook */}
            <DocumentUploadBox
              title="4. Bank Passbook / Cheque"
              description="Verbatim extraction: account_holder_name, account_number, ifsc_code, bank_name"
              docType="bank_passbook"
              extraction={extractions.bank_passbook}
              loading={loadingExtract.bank_passbook}
              onExtract={(file) => handleExtractDocument('bank_passbook', file)}
            />
          </div>

          {/* Action button to proceed to eligibility & auto-filled form */}
          <div style={{ textAlign: 'right' }}>
            <button
              onClick={runEligibilityCheck}
              disabled={loadingEligibility}
              className="btn btn-saffron"
              style={{ padding: '14px 28px', fontSize: '16px' }}
            >
              {loadingEligibility ? 'Evaluating Rules...' : 'Run Eligibility Check & Auto-Fill Form'} <ArrowRight size={18} />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: ELIGIBILITY REPORT & EDITABLE AUTO-FILLED FORM */}
      {step === 2 && eligibilityResult && (
        <div>
          <button onClick={() => setStep(1)} className="btn btn-secondary btn-sm" style={{ marginBottom: '16px' }}>
            ← Back to Document Uploads
          </button>

          {/* ELIGIBILITY MATCH REPORT BOX */}
          <div className="card" style={{ marginBottom: '28px', borderLeft: '5px solid var(--primary-navy)' }}>
            <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--primary-navy)', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Sparkles color="var(--saffron-amber)" size={22} /> Backend Scheme Eligibility Match Report
            </h2>

            {/* Eligible Schemes List */}
            <div style={{ marginBottom: '20px' }}>
              <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--emerald-green)', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                <CheckCircle2 size={18} /> You Qualify For ({eligibilityResult.eligible_schemes.length} Scheme/s):
              </h3>

              {eligibilityResult.eligible_schemes.length === 0 ? (
                <div style={{ padding: '12px', backgroundColor: 'var(--rose-light)', color: 'var(--rose-red)', borderRadius: '6px', fontSize: '13px' }}>
                  No scheme rules matched your current marks, course, or income level.
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                  {eligibilityResult.eligible_schemes.map(sch => (
                    <div key={sch.id} style={{ backgroundColor: 'var(--emerald-light)', border: '1px solid #a7f3d0', padding: '14px', borderRadius: '8px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <strong style={{ fontSize: '16px', color: '#065f46' }}>
                          [{sch.code}] {sch.name}
                        </strong>
                        <span className="badge badge-approved">Eligible</span>
                      </div>
                      <ul style={{ marginTop: '8px', paddingLeft: '20px', fontSize: '13px', color: '#047857' }}>
                        {sch.match_reasons.map((r, i) => (
                          <li key={i}>{r}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Ineligible Schemes List */}
            {eligibilityResult.ineligible_schemes.length > 0 && (
              <div>
                <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--rose-red)', marginBottom: '10px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <XCircle size={18} /> Not Eligible For ({eligibilityResult.ineligible_schemes.length} Scheme/s):
                </h3>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {eligibilityResult.ineligible_schemes.map(sch => (
                    <div key={sch.id} style={{ backgroundColor: '#fff5f5', border: '1px solid #fecdd3', padding: '12px', borderRadius: '8px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <strong style={{ fontSize: '14px', color: '#9f1239' }}>
                          [{sch.code}] {sch.name}
                        </strong>
                        <span className="badge badge-rejected">Ineligible</span>
                      </div>
                      <div style={{ marginTop: '6px', fontSize: '13px', color: '#be123c' }}>
                        <strong>Reason:</strong> {sch.reasons.join(' • ')}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* EDITABLE AUTO-FILLED APPLICATION FORM */}
          <form onSubmit={handleSubmitApplication} className="card">
            <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--primary-navy)', marginBottom: '6px' }}>
              Review & Submit Auto-Filled Application Form
            </h2>
            <p style={{ fontSize: '13px', color: 'var(--slate-medium)', marginBottom: '20px' }}>
              All fields below have been pre-filled from your extracted documents. You can edit any value before final submission.
            </p>

            {submitError && (
              <div style={{ padding: '12px', backgroundColor: 'var(--rose-light)', color: 'var(--rose-red)', borderRadius: '6px', fontSize: '13px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <AlertTriangle size={16} /> {submitError}
              </div>
            )}

            {/* Scheme Picker */}
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', fontSize: '14px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '6px' }}>
                Select Target Scholarship Scheme *
              </label>
              <select
                value={formData.scheme_id}
                onChange={e => setFormData({ ...formData, scheme_id: e.target.value })}
                required
                style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px', fontWeight: 600 }}
              >
                <option value="">-- Choose a scheme --</option>
                {eligibilityResult.eligible_schemes.map(sch => (
                  <option key={sch.id} value={sch.id}>
                    [QUALIFIED] {sch.code} - {sch.name}
                  </option>
                ))}
                {eligibilityResult.ineligible_schemes.map(sch => (
                  <option key={sch.id} value={sch.id}>
                    [NOT ELIGIBLE] {sch.code} - {sch.name}
                  </option>
                ))}
              </select>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px', marginBottom: '20px' }}>
              {/* Applicant Name */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Full Name (as per certificates)
                </label>
                <input
                  type="text"
                  value={formData.applicant_name}
                  onChange={e => setFormData({ ...formData, applicant_name: e.target.value })}
                  required
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Category */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Social Category
                </label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                  required
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Course Level */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Course Level
                </label>
                <input
                  type="text"
                  value={formData.course_level}
                  onChange={e => setFormData({ ...formData, course_level: e.target.value })}
                  required
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Marks % */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Marks Percentage (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.marks_percentage}
                  onChange={e => setFormData({ ...formData, marks_percentage: e.target.value })}
                  required
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Annual Income */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Annual Family Income (₹ INR)
                </label>
                <input
                  type="number"
                  value={formData.annual_income}
                  onChange={e => setFormData({ ...formData, annual_income: e.target.value })}
                  required
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Caste Cert Number */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Caste Certificate Number
                </label>
                <input
                  type="text"
                  value={formData.certificate_number}
                  onChange={e => setFormData({ ...formData, certificate_number: e.target.value })}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Bank Account Number */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Bank Account Number (DBT transfer)
                </label>
                <input
                  type="text"
                  value={formData.account_number}
                  onChange={e => setFormData({ ...formData, account_number: e.target.value })}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* IFSC Code */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Bank IFSC Code
                </label>
                <input
                  type="text"
                  value={formData.ifsc_code}
                  onChange={e => setFormData({ ...formData, ifsc_code: e.target.value })}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>

              {/* Bank Name */}
              <div>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
                  Bank Name
                </label>
                <input
                  type="text"
                  value={formData.bank_name}
                  onChange={e => setFormData({ ...formData, bank_name: e.target.value })}
                  style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
                />
              </div>
            </div>

            <div style={{ borderTop: '1px solid var(--slate-border)', paddingTop: '16px', textAlign: 'right' }}>
              <button
                type="submit"
                disabled={submitting}
                className="btn btn-primary"
                style={{ padding: '12px 24px', fontSize: '15px' }}
              >
                <Send size={16} /> {submitting ? 'Submitting Application...' : 'Submit Application to Ministry'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

// Sub-component for uploading & extracting individual documents
function DocumentUploadBox({ title, description, docType, extraction, loading, onExtract }) {
  return (
    <div className="card" style={{ backgroundColor: '#ffffff' }}>
      <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '4px' }}>
        {title}
      </h3>
      <p style={{ fontSize: '12px', color: 'var(--slate-medium)', marginBottom: '14px' }}>
        {description}
      </p>

      {/* Buttons: Custom file upload & Preset test button */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '14px', flexWrap: 'wrap' }}>
        <label className="btn btn-secondary btn-sm" style={{ cursor: 'pointer' }}>
          <UploadCloud size={14} /> Upload File
          <input
            type="file"
            accept="image/*,.pdf"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                onExtract(e.target.files[0]);
              }
            }}
            style={{ display: 'none' }}
          />
        </label>

        <button
          type="button"
          onClick={() => onExtract(null)}
          disabled={loading}
          className="btn btn-saffron btn-sm"
        >
          <Sparkles size={14} /> Use Preset Sample
        </button>
      </div>

      {loading && (
        <div style={{ padding: '10px', fontSize: '12px', color: 'var(--saffron-amber)', backgroundColor: 'var(--saffron-light)', borderRadius: '6px' }}>
          Calling Gemini Flash AI Vision... extracting fields...
        </div>
      )}

      {/* Structured extracted data card */}
      {extraction && (
        <div style={{ backgroundColor: 'var(--primary-navy-light)', border: '1px solid #cbd5e1', borderRadius: '6px', padding: '10px 12px', fontSize: '12px' }}>
          <div style={{ fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}>
            <CheckCircle2 size={14} color="var(--emerald-green)" /> Gemini Extracted Fields:
          </div>
          <pre style={{ margin: 0, fontFamily: 'monospace', fontSize: '11px', whiteSpace: 'pre-wrap', color: 'var(--slate-dark)' }}>
            {JSON.stringify(extraction, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
