import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, CheckCircle2, XCircle, Clock, RefreshCw, Filter, Search, Edit3, AlertCircle } from 'lucide-react';

export default function AdminDashboard() {
  const { token, user, isAdmin, demoLoginAdmin } = useAuth();

  const [applications, setApplications] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  // Filters
  const [filterScheme, setFilterScheme] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // Action Modal State
  const [selectedApp, setSelectedApp] = useState(null);
  const [newStatus, setNewStatus] = useState('approved');
  const [rejectionReason, setRejectionReason] = useState('');
  const [updating, setUpdating] = useState(false);

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const currentToken = token || localStorage.getItem('scholarship_token');

      // Fetch Applications with filters
      let queryParams = new URLSearchParams();
      if (filterScheme !== 'ALL') queryParams.append('scheme_code', filterScheme);
      if (filterStatus !== 'ALL') queryParams.append('status', filterStatus);
      if (searchTerm) queryParams.append('search', searchTerm);

      const appsRes = await fetch(`http://localhost:5000/api/admin/applications?${queryParams.toString()}`, {
        headers: { Authorization: `Bearer ${currentToken}` }
      });
      const appsData = await appsRes.json();
      if (appsRes.ok) setApplications(appsData);

      // Fetch Aggregate Stats
      const statsRes = await fetch('http://localhost:5000/api/admin/stats', {
        headers: { Authorization: `Bearer ${currentToken}` }
      });
      const statsData = await statsRes.json();
      if (statsRes.ok) setStats(statsData);

    } catch (err) {
      console.error('Admin fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchAdminData();
    }
  }, [token, isAdmin, filterScheme, filterStatus]);

  const handleUpdateStatus = async (e) => {
    e.preventDefault();
    if (!selectedApp) return;

    setUpdating(true);
    try {
      const currentToken = token || localStorage.getItem('scholarship_token');
      const res = await fetch(`http://localhost:5000/api/admin/applications/${selectedApp.id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentToken}`
        },
        body: JSON.stringify({
          status: newStatus,
          rejection_reason: rejectionReason
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update status.');

      alert(`Application #${selectedApp.id} updated to '${newStatus}'`);
      setSelectedApp(null);
      fetchAdminData();
    } catch (err) {
      alert('Update failed: ' + err.message);
    } finally {
      setUpdating(false);
    }
  };

  if (!user || !isAdmin) {
    return (
      <div className="card" style={{ maxWidth: '500px', margin: '40px auto', textAlign: 'center', padding: '32px' }}>
        <ShieldCheck size={48} color="var(--saffron-amber)" style={{ marginBottom: '12px' }} />
        <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--primary-navy)', marginBottom: '8px' }}>
          Ministry Admin Portal Access Required
        </h2>
        <p style={{ fontSize: '13px', color: 'var(--slate-medium)', marginBottom: '20px' }}>
          You must be logged in with a Reviewer / Ministry Admin role to access this dashboard.
        </p>
        <button
          onClick={async () => {
            await demoLoginAdmin();
            fetchAdminData();
          }}
          className="btn btn-saffron"
        >
          Login as Demo Ministry Admin
        </button>
      </div>
    );
  }

  return (
    <div>
      {/* Admin Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--saffron-amber)', backgroundColor: 'var(--saffron-light)', padding: '2px 8px', borderRadius: '4px' }}>
            MINISTRY REVIEWER PORTAL
          </span>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--primary-navy)', marginTop: '4px' }}>
            Scholarship Application Verification Workspace
          </h1>
        </div>

        <button onClick={fetchAdminData} className="btn btn-secondary btn-sm">
          <RefreshCw size={14} /> Refresh Workspace
        </button>
      </div>

      {/* Aggregate Stats Bar */}
      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '28px' }}>
          <div className="card">
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Total Applications</div>
            <div style={{ fontSize: '26px', fontWeight: 800, color: 'var(--primary-navy)' }}>
              {stats.total_applications}
            </div>
          </div>

          <div className="card">
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Approved</div>
            <div style={{ fontSize: '26px', fontWeight: 800, color: 'var(--emerald-green)' }}>
              {stats.status_counts?.approved || 0}
            </div>
          </div>

          <div className="card">
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Under Review / Pending</div>
            <div style={{ fontSize: '26px', fontWeight: 800, color: 'var(--saffron-amber)' }}>
              {(stats.status_counts?.submitted || 0) + (stats.status_counts?.under_review || 0)}
            </div>
          </div>

          <div className="card">
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Rejected / Action Needed</div>
            <div style={{ fontSize: '26px', fontWeight: 800, color: 'var(--rose-red)' }}>
              {(stats.status_counts?.rejected || 0) + (stats.status_counts?.needs_resubmission || 0)}
            </div>
          </div>

          <div className="card">
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Avg Processing Time</div>
            <div style={{ fontSize: '22px', fontWeight: 700, color: 'var(--slate-dark)' }}>
              {stats.avg_processing_time}
            </div>
          </div>
        </div>
      )}

      {/* Scheme Breakdown Overview Table */}
      {stats?.scheme_breakdown && (
        <div className="card" style={{ marginBottom: '28px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '12px' }}>
            Scheme Breakdown Analytics (Eligible vs Rejected)
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '14px' }}>
            {stats.scheme_breakdown.map(sch => (
              <div key={sch.scheme_code} style={{ backgroundColor: 'var(--bg-main)', padding: '14px', borderRadius: '8px', border: '1px solid var(--slate-border)' }}>
                <div style={{ fontWeight: 700, color: 'var(--primary-navy)', fontSize: '14px' }}>
                  {sch.scheme_code} - {sch.scheme_name}
                </div>
                <div style={{ display: 'flex', gap: '12px', marginTop: '8px', fontSize: '12px' }}>
                  <span>Total: <strong>{sch.total}</strong></span>
                  <span style={{ color: 'var(--emerald-green)' }}>Approved: <strong>{sch.approved}</strong></span>
                  <span style={{ color: 'var(--rose-red)' }}>Rejected: <strong>{sch.rejected}</strong></span>
                  <span style={{ color: 'var(--saffron-amber)' }}>Pending: <strong>{sch.pending}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters & Search Bar */}
      <div className="card" style={{ marginBottom: '20px', display: 'flex', flexWrap: 'wrap', gap: '16px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', fontWeight: 700, color: 'var(--slate-dark)' }}>
            <Filter size={16} /> Filters:
          </div>

          {/* Scheme Filter */}
          <select
            value={filterScheme}
            onChange={e => setFilterScheme(e.target.value)}
            style={{ padding: '6px 10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '13px' }}
          >
            <option value="ALL">All Schemes</option>
            <option value="NFST">NFST</option>
            <option value="NOS">NOS</option>
            <option value="POST_MATRIC">Post-Matric</option>
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            style={{ padding: '6px 10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '13px' }}
          >
            <option value="ALL">All Statuses</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under Review</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
            <option value="needs_resubmission">Needs Resubmission</option>
          </select>
        </div>

        {/* Search */}
        <div style={{ position: 'relative', width: '260px' }}>
          <Search size={14} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--slate-light)' }} />
          <input
            type="text"
            placeholder="Search by name, cert #..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && fetchAdminData()}
            style={{ width: '100%', padding: '6px 10px 6px 30px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '13px' }}
          />
        </div>
      </div>

      {/* Applications Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--slate-medium)' }}>Loading verification table...</div>
        ) : applications.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--slate-medium)' }}>
            No applications match the current filter criteria.
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: 'var(--bg-main)', borderBottom: '1px solid var(--slate-border)', color: 'var(--slate-medium)' }}>
                <th style={{ padding: '12px 16px' }}>App ID</th>
                <th style={{ padding: '12px 16px' }}>Applicant</th>
                <th style={{ padding: '12px 16px' }}>Scheme</th>
                <th style={{ padding: '12px 16px' }}>Course / Marks</th>
                <th style={{ padding: '12px 16px' }}>Annual Income</th>
                <th style={{ padding: '12px 16px' }}>Status</th>
                <th style={{ padding: '12px 16px', textAlign: 'right' }}>Review Action</th>
              </tr>
            </thead>
            <tbody>
              {applications.map(app => (
                <tr key={app.id} style={{ borderBottom: '1px solid var(--slate-border)' }}>
                  <td style={{ padding: '12px 16px', fontWeight: 700, color: 'var(--primary-navy)' }}>
                    #{app.id}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{app.applicant_name}</div>
                    <div style={{ fontSize: '11px', color: 'var(--slate-light)' }}>{app.applicant_email} • Cert: {app.certificate_number || 'N/A'}</div>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span style={{ backgroundColor: 'var(--primary-navy-light)', color: 'var(--primary-navy)', padding: '2px 6px', borderRadius: '4px', fontSize: '11px', fontWeight: 700 }}>
                      {app.scheme_code}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ fontWeight: 600 }}>{app.course_level}</div>
                    <div style={{ fontSize: '11px', color: 'var(--slate-medium)' }}>Marks: {app.marks_percentage}%</div>
                  </td>
                  <td style={{ padding: '12px 16px', color: 'var(--emerald-green)', fontWeight: 600 }}>
                    ₹{app.annual_income?.toLocaleString('en-IN')}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span className={`badge badge-${app.status}`}>
                      {app.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button
                      onClick={() => {
                        setSelectedApp(app);
                        setNewStatus(app.status === 'submitted' ? 'approved' : app.status);
                        setRejectionReason(app.rejection_reason || '');
                      }}
                      className="btn btn-primary btn-sm"
                    >
                      <Edit3 size={13} /> Verify / Action
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* REVIEW & STATUS CHANGE MODAL */}
      {selectedApp && (
        <div className="modal-overlay" onClick={() => setSelectedApp(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()} style={{ padding: '24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--slate-border)', paddingBottom: '12px' }}>
              <div>
                <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--saffron-amber)' }}>
                  MINISTRY VERIFICATION WORKFLOW
                </span>
                <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--primary-navy)' }}>
                  Review Application #{selectedApp.id} ({selectedApp.applicant_name})
                </h2>
              </div>
              <button onClick={() => setSelectedApp(null)} className="btn btn-secondary btn-sm">Close</button>
            </div>

            {/* Applicant detail snapshot */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', backgroundColor: 'var(--bg-main)', padding: '14px', borderRadius: '8px', fontSize: '12px', marginBottom: '20px' }}>
              <div><strong>Scheme:</strong> {selectedApp.scheme_name} ({selectedApp.scheme_code})</div>
              <div><strong>Course:</strong> {selectedApp.course_level}</div>
              <div><strong>Marks %:</strong> {selectedApp.marks_percentage}%</div>
              <div><strong>Income:</strong> ₹{selectedApp.annual_income?.toLocaleString('en-IN')}</div>
              <div><strong>Caste Cert #:</strong> {selectedApp.certificate_number || 'N/A'}</div>
              <div><strong>Bank Account #:</strong> {selectedApp.account_number} ({selectedApp.ifsc_code})</div>
            </div>

            {/* Form to update status */}
            <form onSubmit={handleUpdateStatus}>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '6px' }}>
                  Update Application Status:
                </label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value)}
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px', fontWeight: 600 }}
                >
                  <option value="approved">Approved (Verified & Ready for Disbursement)</option>
                  <option value="under_review">Under Review (Pending Manual Verification)</option>
                  <option value="needs_resubmission">Needs Resubmission (Request Updated Docs)</option>
                  <option value="rejected">Rejected (Disqualified)</option>
                </select>
              </div>

              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '6px' }}>
                  Review Notes / Rejection Reason (visible to applicant):
                </label>
                <textarea
                  rows="3"
                  value={rejectionReason}
                  onChange={e => setRejectionReason(e.target.value)}
                  placeholder="e.g. Caste certificate number verified against State DB. Application approved for DBT."
                  style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '13px', fontFamily: 'inherit' }}
                />
              </div>

              <div style={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button type="button" onClick={() => setSelectedApp(null)} className="btn btn-secondary btn-sm">
                  Cancel
                </button>
                <button type="submit" disabled={updating} className="btn btn-saffron btn-sm">
                  {updating ? 'Saving Status...' : 'Save Decision'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
