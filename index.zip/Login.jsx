import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LogIn, UserCheck, ShieldCheck, AlertTriangle } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { login, demoLoginStudent, demoLoginAdmin } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const user = await login(email, password);
      if (user.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/apply');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '440px', margin: '40px auto' }}>
      <div className="card">
        <div style={{ textAlign: 'center', marginBottom: '20px' }}>
          <h1 style={{ fontSize: '22px', fontWeight: 800, color: 'var(--primary-navy)' }}>
            Scholarship Portal Login
          </h1>
          <p style={{ fontSize: '13px', color: 'var(--slate-medium)' }}>
            Log in to manage your ST scholarship applications
          </p>
        </div>

        {/* Quick Demo Preset Login Buttons */}
        <div style={{ backgroundColor: 'var(--primary-navy-light)', border: '1px solid #cbd5e1', padding: '14px', borderRadius: '8px', marginBottom: '20px', textAlign: 'center' }}>
          <div style={{ fontSize: '12px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '8px' }}>
            1-Click Demo Login Options
          </div>
          <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              type="button"
              onClick={async () => {
                await demoLoginStudent();
                navigate('/apply');
              }}
              className="btn btn-secondary btn-sm"
            >
              <UserCheck size={14} /> Login as Student
            </button>

            <button
              type="button"
              onClick={async () => {
                await demoLoginAdmin();
                navigate('/admin');
              }}
              className="btn btn-saffron btn-sm"
            >
              <ShieldCheck size={14} /> Login as Admin
            </button>
          </div>
        </div>

        {error && (
          <div style={{ padding: '10px', backgroundColor: 'var(--rose-light)', color: 'var(--rose-red)', borderRadius: '6px', fontSize: '13px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <AlertTriangle size={16} /> {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '14px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              placeholder="rahul.st@example.com"
              style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', fontSize: '13px', fontWeight: 600, color: 'var(--slate-dark)', marginBottom: '4px' }}>
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              style={{ width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid var(--slate-border)', fontSize: '14px' }}
            />
          </div>

          <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', padding: '12px' }}>
            <LogIn size={16} /> {loading ? 'Logging in...' : 'Sign In'}
          </button>
        </form>

        <div style={{ marginTop: '16px', textAlign: 'center', fontSize: '13px', color: 'var(--slate-medium)' }}>
          Don't have an account? <Link to="/register" style={{ color: 'var(--primary-navy)', fontWeight: 700 }}>Register Here</Link>
        </div>
      </div>
    </div>
  );
}
