import React from 'react';

export default function Footer() {
  return (
    <footer style={{ backgroundColor: '#ffffff', borderTop: '1px solid var(--slate-border)', marginTop: '40px', padding: '32px 20px', fontSize: '13px', color: 'var(--slate-medium)' }}>
      <div style={{ maxWidth: '1280px', margin: '0 auto', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', gap: '24px' }}>
        <div style={{ maxWidth: '450px' }}>
          <div style={{ fontWeight: 700, color: 'var(--primary-navy)', fontSize: '15px', marginBottom: '8px' }}>
            Scholarship Auto-Filer • Ministry of Tribal Affairs
          </div>
          <p style={{ lineHeight: 1.6, marginBottom: '12px' }}>
            Automated document extraction and scheme eligibility matching platform designed specifically for Scheduled Tribe (ST) students pursuing higher education across India and overseas.
          </p>
          <div style={{ fontSize: '11px', color: 'var(--slate-light)' }}>
            Strict Privacy Guarantee: Uploaded caste certificates, marksheets, and financial documents are protected with role-based access control and evaluated using deterministic backend rule-matching.
          </div>
        </div>

        <div>
          <div style={{ fontWeight: 700, color: 'var(--slate-dark)', marginBottom: '10px' }}>Government Schemes</div>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <li>National Fellowship for Higher Education of ST Students (NFST)</li>
            <li>National Overseas Scholarship (NOS) for ST</li>
            <li>Post-Matric Scholarship for ST Students</li>
          </ul>
        </div>

        <div>
          <div style={{ fontWeight: 700, color: 'var(--slate-dark)', marginBottom: '10px' }}>Help & Support</div>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '6px' }}>
            <li>Toll-Free Student Helpline: 1800-11-9988</li>
            <li>Email: support-scholarships@tribal.gov.in</li>
            <li>Shastri Bhawan, New Delhi - 110001</li>
          </ul>
        </div>
      </div>

      <div style={{ maxWidth: '1280px', margin: '24px auto 0', paddingTop: '16px', borderTop: '1px solid var(--slate-border)', textAlign: 'center', fontSize: '12px', color: 'var(--slate-light)' }}>
        © 2026 Ministry of Tribal Affairs, Government of India. Designed for instant ST student scholarship applications.
      </div>
    </footer>
  );
}
