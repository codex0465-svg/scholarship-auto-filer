import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';

import db, { initDatabase } from './db.js';
import { authenticateToken, requireRole, generateToken } from './auth.js';
import { extractDocumentFields } from './gemini.js';
import { evaluateEligibility } from './eligibility.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Initialize Database
initDatabase();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Upload directory
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});
const upload = multer({ storage });

// ----------------------------------------------------
// AUTH ROUTES
// ----------------------------------------------------

app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, full_name, role = 'applicant' } = req.body;
    if (!email || !password || !full_name) {
      return res.status(400).json({ error: 'Email, password, and full name are required.' });
    }

    const checkStmt = db.prepare('SELECT id FROM users WHERE email = ?');
    if (checkStmt.get(email)) {
      return res.status(400).json({ error: 'An account with this email already exists.' });
    }

    const password_hash = bcrypt.hashSync(password, 10);
    const insertStmt = db.prepare('INSERT INTO users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)');
    const result = insertStmt.run(email, password_hash, full_name, role);

    const newUser = { id: result.lastInsertRowid, email, full_name, role };
    const token = generateToken(newUser);
    res.status(201).json({ token, user: newUser });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'Server error during registration.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    const user = stmt.get(email);
    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const userObj = { id: user.id, email: user.email, full_name: user.full_name, role: user.role };
    const token = generateToken(userObj);
    res.json({ token, user: userObj });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

app.get('/api/auth/me', authenticateToken, (req, res) => {
  res.json({ user: req.user });
});

// ----------------------------------------------------
// PUBLIC SCHEMES ROUTE
// ----------------------------------------------------

app.get('/api/schemes', (req, res) => {
  try {
    const stmt = db.prepare('SELECT * FROM schemes WHERE active = 1');
    const schemes = stmt.all().map(s => ({
      ...s,
      course_levels: JSON.parse(s.course_levels || '[]'),
      required_docs: JSON.parse(s.required_docs || '[]')
    }));
    res.json(schemes);
  } catch (err) {
    console.error('Fetch schemes error:', err);
    res.status(500).json({ error: 'Failed to retrieve schemes.' });
  }
});

// ----------------------------------------------------
// DOCUMENT EXTRACTION ROUTE (POST /api/extract)
// ----------------------------------------------------

app.post('/api/extract', authenticateToken, upload.single('document'), async (req, res) => {
  try {
    const documentType = req.body.document_type;
    if (!req.file && !req.body.preset_sample) {
      return res.status(400).json({ error: 'No document file uploaded.' });
    }

    let filePath, fileName, mimeType;
    if (req.file) {
      filePath = req.file.path;
      fileName = req.file.originalname;
      mimeType = req.file.mimetype;
    } else {
      filePath = path.join(uploadsDir, 'sample_placeholder.png');
      fileName = `sample_${documentType}.png`;
      mimeType = 'image/png';
    }

    const extractedData = await extractDocumentFields(filePath, mimeType, documentType);

    const insertDoc = db.prepare(`
      INSERT INTO documents (applicant_id, document_type, file_name, file_path, mime_type, extracted_data)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    const docResult = insertDoc.run(
      req.user.id,
      documentType,
      fileName,
      filePath,
      mimeType,
      JSON.stringify(extractedData)
    );

    res.json({
      document_id: docResult.lastInsertRowid,
      document_type: documentType,
      extracted_data: extractedData
    });
  } catch (err) {
    console.error('Extract error:', err);
    res.status(500).json({ error: 'Failed to extract document fields: ' + err.message });
  }
});

// ----------------------------------------------------
// ELIGIBILITY PREDICTION ROUTE (POST /api/eligibility)
// ----------------------------------------------------

app.post('/api/eligibility', authenticateToken, (req, res) => {
  try {
    const { category, course_level, annual_income, marks_percentage } = req.body;
    const result = evaluateEligibility({ category, course_level, annual_income, marks_percentage });
    res.json(result);
  } catch (err) {
    console.error('Eligibility evaluation error:', err);
    res.status(500).json({ error: 'Failed to compute eligibility.' });
  }
});

// ----------------------------------------------------
// APPLICATIONS ROUTES
// ----------------------------------------------------

app.post('/api/applications', authenticateToken, (req, res) => {
  try {
    const {
      scheme_id,
      applicant_name,
      category,
      course_level,
      annual_income,
      marks_percentage,
      certificate_number,
      account_number,
      ifsc_code,
      bank_name
    } = req.body;

    if (!scheme_id) {
      return res.status(400).json({ error: 'Scheme ID is required.' });
    }

    const scheme = db.prepare('SELECT * FROM schemes WHERE id = ?').get(scheme_id);
    if (!scheme) {
      return res.status(404).json({ error: 'Scholarship scheme not found.' });
    }

    const insertApp = db.prepare(`
      INSERT INTO applications (
        applicant_id, applicant_name, scheme_id, scheme_code, scheme_name,
        category, course_level, annual_income, marks_percentage,
        certificate_number, account_number, ifsc_code, bank_name, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted')
    `);

    const result = insertApp.run(
      req.user.id,
      applicant_name || req.user.full_name,
      scheme.id,
      scheme.code,
      scheme.name,
      category || 'ST',
      course_level || 'PhD',
      parseFloat(annual_income) || 0,
      parseFloat(marks_percentage) || 0,
      certificate_number || null,
      account_number || null,
      ifsc_code || null,
      bank_name || null
    );

    res.status(201).json({
      message: 'Application submitted successfully!',
      application_id: result.lastInsertRowid,
      scheme_name: scheme.name,
      status: 'submitted'
    });
  } catch (err) {
    console.error('Submit application error:', err);
    res.status(500).json({ error: 'Failed to submit application: ' + err.message });
  }
});

app.get('/api/applications/mine', authenticateToken, (req, res) => {
  try {
    const apps = db.prepare('SELECT * FROM applications WHERE applicant_id = ? ORDER BY submitted_at DESC').all(req.user.id);
    res.json(apps);
  } catch (err) {
    console.error('Fetch my applications error:', err);
    res.status(500).json({ error: 'Failed to fetch applications.' });
  }
});

// ----------------------------------------------------
// ADMIN ROUTES
// ----------------------------------------------------

app.get('/api/admin/applications', authenticateToken, requireRole('admin'), (req, res) => {
  try {
    const { scheme_code, status, search } = req.query;
    let sql = `SELECT a.*, u.email as applicant_email FROM applications a JOIN users u ON a.applicant_id = u.id WHERE 1=1`;
    const params = [];

    if (scheme_code && scheme_code !== 'ALL') {
      sql += ` AND a.scheme_code = ?`;
      params.push(scheme_code);
    }
    if (status && status !== 'ALL') {
      sql += ` AND a.status = ?`;
      params.push(status);
    }
    if (search) {
      sql += ` AND (a.applicant_name LIKE ? OR a.certificate_number LIKE ? OR u.email LIKE ?)`;
      const term = `%${search}%`;
      params.push(term, term, term);
    }

    sql += ` ORDER BY a.submitted_at DESC`;
    const applications = db.prepare(sql).all(...params);
    res.json(applications);
  } catch (err) {
    console.error('Admin fetch applications error:', err);
    res.status(500).json({ error: 'Failed to fetch applications list.' });
  }
});

app.patch('/api/admin/applications/:id/status', authenticateToken, requireRole('admin'), (req, res) => {
  try {
    const { id } = req.params;
    const { status, rejection_reason } = req.body;

    const validStatuses = ['submitted', 'under_review', 'approved', 'rejected', 'needs_resubmission'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status value.' });
    }

    const result = db.prepare(`
      UPDATE applications 
      SET status = ?, rejection_reason = ?, updated_at = CURRENT_TIMESTAMP 
      WHERE id = ?
    `).run(status, rejection_reason || null, id);

    if (result.changes === 0) {
      return res.status(404).json({ error: 'Application record not found.' });
    }

    res.json({ message: `Application status updated to '${status}'`, id, status });
  } catch (err) {
    console.error('Admin update status error:', err);
    res.status(500).json({ error: 'Failed to update application status.' });
  }
});

app.get('/api/admin/stats', authenticateToken, requireRole('admin'), (req, res) => {
  try {
    const totalApps = db.prepare('SELECT COUNT(*) as total FROM applications').get().total;

    const statusCounts = db.prepare(`
      SELECT status, COUNT(*) as count FROM applications GROUP BY status
    `).all();

    const schemeBreakdown = db.prepare(`
      SELECT scheme_code, scheme_name, 
             COUNT(*) as total,
             SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
             SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected,
             SUM(CASE WHEN status = 'under_review' OR status = 'submitted' THEN 1 ELSE 0 END) as pending
      FROM applications 
      GROUP BY scheme_code
    `).all();

    res.json({
      total_applications: totalApps,
      status_counts: statusCounts.reduce((acc, curr) => ({ ...acc, [curr.status]: curr.count }), {}),
      scheme_breakdown: schemeBreakdown,
      avg_processing_time: '2.4 days'
    });
  } catch (err) {
    console.error('Admin stats error:', err);
    res.status(500).json({ error: 'Failed to fetch admin stats.' });
  }
});

// ----------------------------------------------------
// SECURE FILE ACCESS ROUTE
// ----------------------------------------------------

app.get('/api/documents/:id/file', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(id);

    if (!doc) return res.status(404).json({ error: 'Document file not found.' });
    if (doc.applicant_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied: You do not have permission to view this document.' });
    }
    if (!fs.existsSync(doc.file_path)) {
      return res.status(404).json({ error: 'File on disk was not found.' });
    }

    res.setHeader('Content-Type', doc.mime_type || 'image/jpeg');
    fs.createReadStream(doc.file_path).pipe(res);
  } catch (err) {
    console.error('Document download error:', err);
    res.status(500).json({ error: 'Failed to stream document file.' });
  }
});

// ----------------------------------------------------
// SERVE FRONTEND STATIC FILES & REACT ROUTER FALLBACK
// ----------------------------------------------------

const frontendDistDir = path.resolve(__dirname, '..', '..', 'frontend', 'dist');

if (fs.existsSync(frontendDistDir)) {
  console.log('Serving frontend static bundle from:', frontendDistDir);
  app.use(express.static(frontendDistDir));

  // Handle SPA client-side routing (catch-all non-API routes)
  app.get('*', (req, res) => {
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ error: 'API endpoint not found' });
    }
    res.sendFile(path.join(frontendDistDir, 'index.html'));
  });
}

// Start Server on 0.0.0.0 (all network interfaces)
app.listen(PORT, '0.0.0.0', () => {
  console.log(`=================================================`);
  console.log(`Scholarship Auto-Filer Web App running at:`);
  console.log(`➜  Local:   http://localhost:${PORT}`);
  console.log(`➜  Network: http://127.0.0.1:${PORT}`);
  console.log(`Database: SQLite (node:sqlite)`);
  console.log(`=================================================`);
});
