import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { FileText, Clock, CheckCircle2, XCircle, AlertCircle, Eye, RefreshCw, Layers } from 'lucide-react';

export default function MyApplications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedApp, setSelectedApp] = useState(null);

  const { token, user } = useAuth();

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const currentToken = token || localStorage.getItem('scholarship_token');
      const res = await fetch('http://localhost:5000/api/applications/mine', {
        headers: { Authorization: `Bearer ${currentToken}` }
      });
      const data = await res.json();
      if (res.ok) {
        setApplications(data);
      }
    } catch (err) {
      console.error('Fetch my applications error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, [token]);

  // Aggregate counts
  const total = applications.length;
  const underReview = applications.filter(a => a.status === 'under_review' || a.status === 'submitted').length;
  const approved = applications.filter(a => a.status === 'approved').length;
  const rejected = applications.filter(a => a.status === 'rejected' || a.status === 'needs_resubmission').length;

  return (
    <div>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <div>
          <h1 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--primary-navy)' }}>
            My Submitted Scholarship Applications
          </h1>
          <p style={{ fontSize: '14px', color: 'var(--slate-medium)' }}>
            Track the status of your scholarship applications submitted to the Ministry of Tribal Affairs.
          </p>
        </div>

        <button onClick={fetchApplications} className="btn btn-secondary btn-sm">
          <RefreshCw size={14} /> Refresh List
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '28px' }}>
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{ backgroundColor: 'var(--primary-navy-light)', color: 'var(--primary-navy)', padding: '12px', borderRadius: '10px' }}>
            <Layers size={24} />
          </div>
          <div>
            <div style={{ fontSize: '22px', fontWeight: 800, color: 'var(--primary-navy)' }}>{total}</div>
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Total Submitted</div>
          </div>
        </div>

        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{ backgroundColor: 'var(--saffron-light)', color: 'var(--saffron-amber)', padding: '12px', borderRadius: '10px' }}>
            <Clock size={24} />
          </div>
          <div>
            <div style={{ fontSize: '22px', fontWeight: 800, color: 'var(--saffron-amber)' }}>{underReview}</div>
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Under Review</div>
          </div>
        </div>

        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{ backgroundColor: 'var(--emerald-light)', color: 'var(--emerald-green)', padding: '12px', borderRadius: '10px' }}>
            <CheckCircle2 size={24} />
          </div>
          <div>
            <div style={{ fontSize: '22px', fontWeight: 800, color: 'var(--emerald-green)' }}>{approved}</div>
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Approved</div>
          </div>
        </div>

        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{ backgroundColor: 'var(--rose-light)', color: 'var(--rose-red)', padding: '12px', borderRadius: '10px' }}>
            <XCircle size={24} />
          </div>
          <div>
            <div style={{ fontSize: '22px', fontWeight: 800, color: 'var(--rose-red)' }}>{rejected}</div>
            <div style={{ fontSize: '12px', color: 'var(--slate-medium)' }}>Needs Action / Rejected</div>
          </div>
        </div>
      </div>

      {/* Applications Table */}
      <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--slate-border)', fontWeight: 700, color: 'var(--primary-navy)', fontSize: '16px' }}>
          Application History
        </div>

        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--slate-medium)' }}>Loading applications...</div>
        ) : applications.length === 0 ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--slate-medium)' }}>
            No applications submitted yet. Click "Apply Now" to start your first scholarship auto-filling process!
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px', textAlign: 'left' }}>
            <thead>
              <tr style={{ backgroundColor: 'var(--bg-main)', borderBottom: '1px solid var(--slate-border)', color: 'var(--slate-medium)' }}>
                <th style={{ padding: '12px 16px' }}>App ID</th>
                <th style={{ padding: '12px 16px' }}>Scheme</th>
                <th style={{ padding: '12px 16px' }}>Course</th>
                <th style={{ padding: '12px 16px' }}>Submission Date</th>
                <th style={{ padding: '12px 16px' }}>Status</th>
                <th style={{ padding: '12px 16px', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {applications.map(app => (
                <tr key={app.id} style={{ borderBottom: '1px solid var(--slate-border)' }}>
                  <td style={{ padding: '12px 16px', fontWeight: 700, color: 'var(--primary-navy)' }}>
                    #{app.id}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <div style={{ fontWeight: 600, color: 'var(--slate-dark)' }}>{app.scheme_name}</div>
                    <div style={{ fontSize: '11px', color: 'var(--slate-light)' }}>Code: {app.scheme_code}</div>
                  </td>
                  <td style={{ padding: '12px 16px', fontWeight: 600 }}>
                    {app.course_level}
                  </td>
                  <td style={{ padding: '12px 16px', color: 'var(--slate-medium)' }}>
                    {new Date(app.submitted_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </td>
                  <td style={{ padding: '12px 16px' }}>
                    <span className={`badge badge-${app.status}`}>
                      {app.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                    <button
                      onClick={() => setSelectedApp(app)}
                      className="btn btn-secondary btn-sm"
                    >
                      <Eye size={14} /> View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* DETAIL VIEW MODAL */}
      {selectedApp && (
        <div className="modal-overlay" onClick={() => setSelectedApp(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()} style={{ padding: '24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', borderBottom: '1px solid var(--slate-border)', paddingBottom: '12px' }}>
              <div>
                <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--primary-navy)' }}>
                  APPLICATION DETAIL #{selectedApp.id}
                </span>
                <h2 style={{ fontSize: '20px', fontWeight: 800, color: 'var(--primary-navy)' }}>
                  {selectedApp.scheme_name}
                </h2>
              </div>

              <button onClick={() => setSelectedApp(null)} className="btn btn-secondary btn-sm">
                Close
              </button>
            </div>

            {/* Rejection / Review note alert if present */}
            {selectedApp.rejection_reason && (
              <div style={{ backgroundColor: 'var(--rose-light)', color: 'var(--rose-red)', padding: '12px', borderRadius: '8px', marginBottom: '16px', fontSize: '13px' }}>
                <strong>Ministry Review Note:</strong> {selectedApp.rejection_reason}
              </div>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '14px', fontSize: '13px', backgroundColor: 'var(--bg-main)', padding: '16px', borderRadius: '8px', marginBottom: '20px' }}>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Applicant Name:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.applicant_name}</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Category:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.category}</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Course Level:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.course_level}</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Marks Percentage:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.marks_percentage}%</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Annual Income:</span>
                <div style={{ fontWeight: 700, color: 'var(--emerald-green)' }}>₹{selectedApp.annual_income?.toLocaleString('en-IN')}</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Caste Cert No:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.certificate_number || 'N/A'}</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>Bank Account No:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.account_number || 'N/A'}</div>
              </div>
              <div>
                <span style={{ color: 'var(--slate-medium)' }}>IFSC & Bank Name:</span>
                <div style={{ fontWeight: 700, color: 'var(--slate-dark)' }}>{selectedApp.ifsc_code} ({selectedApp.bank_name})</div>
              </div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <button onClick={() => setSelectedApp(null)} className="btn btn-primary btn-sm">
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
