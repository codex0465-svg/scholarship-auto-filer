import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Award, UploadCloud, Cpu, CheckCircle2, ArrowRight, ShieldCheck, Clock, FileCheck, HelpCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Home() {
  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user, demoLoginStudent } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetch('http://localhost:5000/api/schemes')
      .then(res => res.json())
      .then(data => {
        setSchemes(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load schemes:', err);
        setLoading(false);
      });
  }, []);

  const handleStartApplication = async () => {
    if (!user) {
      await demoLoginStudent();
    }
    navigate('/apply');
  };

  return (
    <div>
      {/* Hero Banner */}
      <section style={{ 
        backgroundColor: '#ffffff', 
        border: '1px solid var(--slate-border)', 
        borderRadius: 'var(--radius-lg)', 
        padding: '40px 32px', 
        marginBottom: '32px',
        boxShadow: 'var(--shadow-sm)',
        display: 'flex',
        flexDirection: 'column',
        gap: '20px'
      }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', backgroundColor: 'var(--saffron-light)', color: 'var(--saffron-amber)', padding: '6px 14px', borderRadius: '9999px', fontSize: '13px', fontWeight: 700, width: 'fit-content' }}>
          <Award size={16} /> Scheduled Tribe (ST) Central Fellowship & Scholarship Portal
        </div>

        <h1 style={{ fontSize: '32px', fontWeight: 800, color: 'var(--primary-navy)', lineHeight: 1.25 }}>
          Scholarship Auto-Filer for Indian ST Students
        </h1>

        <p style={{ fontSize: '16px', color: 'var(--slate-medium)', maxWidth: '850px', lineHeight: 1.6 }}>
          Upload your caste certificate, marksheets, income certificate, and passbook once. Our AI vision system extracts key details automatically, checks eligibility against official Ministry rules (NFST, NOS, Post-Matric), and generates your auto-filled application in seconds.
        </p>

        {/* Action Buttons */}
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '14px', marginTop: '10px' }}>
          <button onClick={handleStartApplication} className="btn btn-primary" style={{ padding: '12px 24px', fontSize: '15px' }}>
            Upload Documents & Check Eligibility <ArrowRight size={18} />
          </button>
          
          <a href="#how-it-works" className="btn btn-secondary" style={{ padding: '12px 20px', fontSize: '15px' }}>
            How It Works
          </a>
        </div>
      </section>

      {/* Value Proposition Box (Plain language paragraph) */}
      <section style={{
        backgroundColor: 'var(--primary-navy-light)',
        border: '1px solid #cbd5e1',
        borderRadius: 'var(--radius-md)',
        padding: '24px',
        marginBottom: '32px',
        display: 'flex',
        alignItems: 'flex-start',
        gap: '16px'
      }}>
        <div style={{ backgroundColor: 'var(--primary-navy)', color: '#ffffff', padding: '10px', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Clock size={28} />
        </div>
        <div>
          <h3 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--primary-navy)', marginBottom: '6px' }}>
            Why Scholarship Auto-Filer Saves ST Applicants Time
          </h3>
          <p style={{ fontSize: '14px', color: 'var(--slate-dark)', lineHeight: 1.6 }}>
            Traditional government scholarship applications require filling out dozens of repetitive fields across multiple portals, often leading to typos in caste certificate numbers, bank account numbers, or income values that cause rejection. Scholarship Auto-Filer eliminates manual data entry by extracting verified fields directly from your uploaded document images using AI vision. It automatically compares your profile against scheme criteria, highlights disqualification reasons transparently, and auto-populates your application form so you can review and submit in under two minutes.
          </p>
        </div>
      </section>

      {/* 3-Step Explainer Section */}
      <section id="how-it-works" style={{ marginBottom: '40px' }}>
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: 800, color: 'var(--primary-navy)' }}>
            How It Works in 3 Simple Steps
          </h2>
          <p style={{ fontSize: '14px', color: 'var(--slate-medium)', marginTop: '4px' }}>
            From raw certificate files to verified scholarship submission
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
          {/* Step 1 */}
          <div className="card" style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'var(--primary-navy-light)', color: 'var(--primary-navy)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', fontWeight: 800, fontSize: '20px' }}>
              1
            </div>
            <UploadCloud size={32} color="var(--primary-navy)" style={{ marginBottom: '12px' }} />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--slate-dark)', marginBottom: '8px' }}>
              Upload Your Documents
            </h3>
            <p style={{ fontSize: '13px', color: 'var(--slate-medium)', lineHeight: 1.5 }}>
              Upload your Caste Certificate, Marksheet, Income Certificate, and Bank Passbook (or use test preset samples).
            </p>
          </div>

          {/* Step 2 */}
          <div className="card" style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'var(--saffron-light)', color: 'var(--saffron-amber)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', fontWeight: 800, fontSize: '20px' }}>
              2
            </div>
            <Cpu size={32} color="var(--saffron-amber)" style={{ marginBottom: '12px' }} />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--slate-dark)', marginBottom: '8px' }}>
              AI Reads Your Documents
            </h3>
            <p style={{ fontSize: '13px', color: 'var(--slate-medium)', lineHeight: 1.5 }}>
              Gemini 2.0 Flash Vision extracts your name, certificate number, income, marks %, and bank account details accurately.
            </p>
          </div>

          {/* Step 3 */}
          <div className="card" style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: '56px', height: '56px', borderRadius: '50%', backgroundColor: 'var(--emerald-light)', color: 'var(--emerald-green)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', fontWeight: 800, fontSize: '20px' }}>
              3
            </div>
            <CheckCircle2 size={32} color="var(--emerald-green)" style={{ marginBottom: '12px' }} />
            <h3 style={{ fontSize: '16px', fontWeight: 700, color: 'var(--slate-dark)', marginBottom: '8px' }}>
              See What You Qualify For
            </h3>
            <p style={{ fontSize: '13px', color: 'var(--slate-medium)', lineHeight: 1.5 }}>
              View matched schemes, review your auto-filled application form, edit if needed, and submit to the Ministry.
            </p>
          </div>
        </div>
      </section>

      {/* Available Schemes Directory */}
      <section style={{ marginBottom: '40px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <div>
            <h2 style={{ fontSize: '22px', fontWeight: 800, color: 'var(--primary-navy)' }}>
              Available Ministry of Tribal Affairs Schemes
            </h2>
            <p style={{ fontSize: '13px', color: 'var(--slate-medium)' }}>
              Official government scholarship schemes currently open for ST applicants
            </p>
          </div>
          <button onClick={handleStartApplication} className="btn btn-saffron btn-sm">
            Apply to All Qualified Schemes
          </button>
        </div>

        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', color: 'var(--slate-medium)' }}>Loading schemes...</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {schemes.map(scheme => (
              <div key={scheme.id} className="card" style={{ borderLeft: '4px solid var(--primary-navy)' }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px', marginBottom: '12px' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                      <span style={{ backgroundColor: 'var(--primary-navy-light)', color: 'var(--primary-navy)', padding: '2px 8px', borderRadius: '4px', fontSize: '12px', fontWeight: 700 }}>
                        {scheme.code}
                      </span>
                      <h3 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--primary-navy)' }}>
                        {scheme.name}
                      </h3>
                    </div>
                    <p style={{ fontSize: '14px', color: 'var(--slate-medium)' }}>
                      {scheme.description}
                    </p>
                  </div>

                  <div style={{ backgroundColor: '#f1f5f9', padding: '8px 14px', borderRadius: '6px', fontSize: '12px', textAlign: 'right' }}>
                    <div style={{ color: 'var(--slate-medium)' }}>Application Deadline</div>
                    <div style={{ fontWeight: 700, color: 'var(--rose-red)' }}>{scheme.deadline}</div>
                  </div>
                </div>

                {/* Requirements breakdown */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '12px', backgroundColor: 'var(--bg-main)', padding: '12px 16px', borderRadius: '8px', fontSize: '13px' }}>
                  <div>
                    <span style={{ color: 'var(--slate-medium)' }}>Category Required: </span>
                    <strong style={{ color: 'var(--primary-navy)' }}>{scheme.category_required}</strong>
                  </div>
                  <div>
                    <span style={{ color: 'var(--slate-medium)' }}>Course Level: </span>
                    <strong style={{ color: 'var(--slate-dark)' }}>{scheme.course_levels.join(', ')}</strong>
                  </div>
                  <div>
                    <span style={{ color: 'var(--slate-medium)' }}>Min Marks: </span>
                    <strong style={{ color: 'var(--slate-dark)' }}>{scheme.min_marks}%</strong>
                  </div>
                  <div>
                    <span style={{ color: 'var(--slate-medium)' }}>Income Cap: </span>
                    <strong style={{ color: 'var(--emerald-green)' }}>
                      {scheme.income_cap > 0 ? `₹${scheme.income_cap.toLocaleString('en-IN')}/year` : 'No Limit'}
                    </strong>
                  </div>
                </div>

                <div style={{ marginTop: '14px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '10px' }}>
                  <div style={{ fontSize: '12px', color: 'var(--slate-medium)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                    <FileCheck size={16} color="var(--primary-navy)" />
                    Required Documents: {scheme.required_docs.join(' • ')}
                  </div>

                  <button onClick={handleStartApplication} className="btn btn-primary btn-sm">
                    Apply for {scheme.code} <ArrowRight size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
