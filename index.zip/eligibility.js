import db from './db.js';

export function evaluateEligibility(applicantData) {
  const { category, course_level, annual_income, marks_percentage } = applicantData;

  const getSchemesStmt = db.prepare('SELECT * FROM schemes WHERE active = 1');
  const schemes = getSchemesStmt.all();

  const eligible_schemes = [];
  const ineligible_schemes = [];

  for (const scheme of schemes) {
    const reasons = [];
    let isEligible = true;

    const allowedCourses = JSON.parse(scheme.course_levels || '[]');
    const requiredCategory = scheme.category_required;
    const minMarks = scheme.min_marks;
    const incomeCap = scheme.income_cap;

    // 1. Category Check
    if (!category || category.toUpperCase() !== requiredCategory.toUpperCase()) {
      isEligible = false;
      reasons.push(`Category '${category || 'Unspecified'}' does not match required category '${requiredCategory}'`);
    }

    // 2. Course Level Check
    if (!course_level || !allowedCourses.includes(course_level)) {
      isEligible = false;
      reasons.push(`Course level '${course_level || 'Unspecified'}' is not eligible. Allowed: ${allowedCourses.join(', ')}`);
    }

    // 3. Minimum Marks Check
    const studentMarks = parseFloat(marks_percentage) || 0;
    if (studentMarks < minMarks) {
      isEligible = false;
      reasons.push(`Marks percentage (${studentMarks}%) is below minimum required (${minMarks}%)`);
    }

    // 4. Income Cap Check (0 means no cap)
    const income = parseFloat(annual_income) || 0;
    if (incomeCap > 0 && income > incomeCap) {
      isEligible = false;
      reasons.push(`Annual income (₹${income.toLocaleString('en-IN')}) exceeds income cap of ₹${incomeCap.toLocaleString('en-IN')}`);
    }

    if (isEligible) {
      const matchReasons = [
        `Category matches '${requiredCategory}'`,
        `Course level '${course_level}' is eligible`,
        `Marks (${studentMarks}%) meet minimum ${minMarks}%`
      ];
      if (incomeCap > 0) {
        matchReasons.push(`Income ₹${income.toLocaleString('en-IN')} is within ₹${incomeCap.toLocaleString('en-IN')} limit`);
      } else {
        matchReasons.push(`No income cap requirement`);
      }

      eligible_schemes.push({
        id: scheme.id,
        code: scheme.code,
        name: scheme.name,
        description: scheme.description,
        deadline: scheme.deadline,
        match_reasons: matchReasons
      });
    } else {
      ineligible_schemes.push({
        id: scheme.id,
        code: scheme.code,
        name: scheme.name,
        description: scheme.description,
        reasons: reasons
      });
    }
  }

  return { eligible_schemes, ineligible_schemes };
}
