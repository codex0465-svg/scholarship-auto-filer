import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbPath = path.join(__dirname, '..', 'scholarship.db');
const db = new DatabaseSync(dbPath);

// Enable foreign keys
db.exec('PRAGMA foreign_keys = ON;');

export function initDatabase() {
  console.log('Initializing SQLite database at:', dbPath);

  // Users table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT CHECK(role IN ('applicant', 'admin')) NOT NULL DEFAULT 'applicant',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Schemes table
  db.exec(`
    CREATE TABLE IF NOT EXISTS schemes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      description TEXT NOT NULL,
      category_required TEXT NOT NULL,
      min_marks REAL NOT NULL,
      income_cap REAL NOT NULL,
      course_levels TEXT NOT NULL,
      required_docs TEXT NOT NULL,
      active INTEGER DEFAULT 1,
      deadline TEXT DEFAULT '2026-11-30'
    );
  `);

  // Documents table
  db.exec(`
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      applicant_id INTEGER NOT NULL,
      document_type TEXT NOT NULL,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      extracted_data TEXT,
      uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (applicant_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  // Applications table
  db.exec(`
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      applicant_id INTEGER NOT NULL,
      applicant_name TEXT NOT NULL,
      scheme_id INTEGER NOT NULL,
      scheme_code TEXT NOT NULL,
      scheme_name TEXT NOT NULL,
      category TEXT NOT NULL,
      course_level TEXT NOT NULL,
      annual_income REAL NOT NULL,
      marks_percentage REAL NOT NULL,
      certificate_number TEXT,
      account_number TEXT,
      ifsc_code TEXT,
      bank_name TEXT,
      status TEXT CHECK(status IN ('submitted', 'under_review', 'approved', 'rejected', 'needs_resubmission')) DEFAULT 'submitted',
      rejection_reason TEXT,
      submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (applicant_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (scheme_id) REFERENCES schemes(id)
    );
  `);

  seedInitialData();
}

function seedInitialData() {
  // Seed Users
  const checkUserStmt = db.prepare('SELECT COUNT(*) as count FROM users');
  const userCount = checkUserStmt.get().count;

  if (userCount === 0) {
    console.log('Seeding initial admin and applicant accounts...');
    const adminHash = bcrypt.hashSync('admin123', 10);
    const studentHash = bcrypt.hashSync('student123', 10);

    const insertUser = db.prepare(`
      INSERT INTO users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)
    `);

    insertUser.run('admin@tribal.gov.in', adminHash, 'Ministry Reviewer', 'admin');
    insertUser.run('rahul.st@example.com', studentHash, 'Rahul Kumar Marandi', 'applicant');
  }

  // Seed Schemes
  const checkSchemeStmt = db.prepare('SELECT COUNT(*) as count FROM schemes');
  const schemeCount = checkSchemeStmt.get().count;

  if (schemeCount === 0) {
    console.log('Seeding ST Scholarship schemes (NFST, NOS, Post-Matric)...');
    const insertScheme = db.prepare(`
      INSERT INTO schemes (code, name, description, category_required, min_marks, income_cap, course_levels, required_docs, deadline)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    // NFST: MPhil/PhD, category ST, min_marks 55, no income cap (0)
    insertScheme.run(
      'NFST',
      'National Fellowship for Higher Education of ST Students',
      'Fellowship provided by the Ministry of Tribal Affairs for ST students pursuing MPhil and PhD degrees in Indian Universities.',
      'ST',
      55.0,
      0, // 0 indicates no income cap
      JSON.stringify(['MPhil', 'PhD']),
      JSON.stringify(['Caste Certificate', 'Marksheet', 'Income Certificate', 'Bank Passbook']),
      '2026-12-15'
    );

    // NOS: Masters/PhD, category ST, min_marks 60, income cap 600,000 INR
    insertScheme.run(
      'NOS',
      'National Overseas Scholarship for ST Students',
      'Financial assistance provided to meritorious ST students for pursuing Masters, PhD, and Post-Doctoral studies abroad.',
      'ST',
      60.0,
      600000,
      JSON.stringify(['Masters', 'PhD']),
      JSON.stringify(['Caste Certificate', 'Marksheet', 'Income Certificate', 'Bank Passbook']),
      '2026-11-30'
    );

    // Post-Matric Scholarship: UG/PG, category ST, min_marks 50, income cap 250,000 INR
    insertScheme.run(
      'POST_MATRIC',
      'Post-Matric Scholarship for ST Students',
      'Centrally sponsored scheme providing financial support to ST students studying at post-matriculation or post-secondary stage (UG/PG).',
      'ST',
      50.0,
      250000,
      JSON.stringify(['UG', 'PG']),
      JSON.stringify(['Caste Certificate', 'Marksheet', 'Income Certificate', 'Bank Passbook']),
      '2026-10-31'
    );
  }

  // Seed sample applications if empty
  const checkAppStmt = db.prepare('SELECT COUNT(*) as count FROM applications');
  const appCount = checkAppStmt.get().count;

  if (appCount === 0) {
    const student = db.prepare("SELECT id FROM users WHERE email = 'rahul.st@example.com'").get();
    const nfstScheme = db.prepare("SELECT id, name FROM schemes WHERE code = 'NFST'").get();
    
    if (student && nfstScheme) {
      const insertApp = db.prepare(`
        INSERT INTO applications (
          applicant_id, applicant_name, scheme_id, scheme_code, scheme_name,
          category, course_level, annual_income, marks_percentage,
          certificate_number, account_number, ifsc_code, bank_name, status, rejection_reason
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insertApp.run(
        student.id,
        'Rahul Kumar Marandi',
        nfstScheme.id,
        'NFST',
        nfstScheme.name,
        'ST',
        'PhD',
        210000,
        72.5,
        'ST-JH-2024-88912',
        '987654321012',
        'SBIN0001234',
        'State Bank of India',
        'under_review',
        null
      );
    }
  }
}

export default db;
