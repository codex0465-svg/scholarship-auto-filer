import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Award, FileText, User, ShieldCheck, LogOut, LogIn, ChevronRight } from 'lucide-react';

export default function Navbar() {
  const { user, logout, demoLoginStudent, demoLoginAdmin, isAdmin } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path) => location.pathname === path;

  return (
    <header style={{ backgroundColor: '#ffffff', borderBottom: '1px solid var(--slate-border)', sticky: 'top', zIndex: 100 }}>
      {/* Top Banner - Govt branding */}
      <div style={{ backgroundColor: 'var(--primary-navy)', color: '#ffffff', padding: '6px 20px', fontSize: '12px', fontWeight: 500, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span style={{ display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%', backgroundColor: 'var(--saffron-amber)' }}></span>
          <span>Ministry of Tribal Affairs • Government of India National Portal</span>
        </div>
        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
          {!user ? (
            <>
              <button 
                onClick={async () => { await demoLoginStudent(); navigate('/apply'); }}
                style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', border: 'none', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', cursor: 'pointer' }}
              >
                Demo Student Login
              </button>
              <button 
                onClick={async () => { await demoLoginAdmin(); navigate('/admin'); }}
                style={{ background: 'var(--saffron-amber)', color: '#fff', border: 'none', padding: '2px 8px', borderRadius: '4px', fontSize: '11px', cursor: 'pointer', fontWeight: 600 }}
              >
                Demo Admin Login
              </button>
            </>
          ) : (
            <span style={{ color: '#cbd5e1' }}>
              Role: <strong style={{ color: '#ffffff', textTransform: 'capitalize' }}>{user.role}</strong> ({user.email})
            </span>
          )}
        </div>
      </div>

      {/* Main Navbar */}
      <div style={{ maxWidth: '1280px', margin: '0 auto', padding: '12px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        {/* Brand */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ width: '42px', height: '42px', borderRadius: '10px', backgroundColor: 'var(--primary-navy-light)', border: '1px solid #cbd5e1', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary-navy)' }}>
            <Award size={26} />
          </div>
          <div>
            <div style={{ fontSize: '18px', fontWeight: 800, color: 'var(--primary-navy)', letterSpacing: '-0.02em', display: 'flex', alignItems: 'center', gap: '6px' }}>
              Scholarship Auto-Filer
              <span style={{ fontSize: '10px', backgroundColor: 'var(--saffron-light)', color: 'var(--saffron-amber)', padding: '2px 6px', borderRadius: '4px', fontWeight: 700 }}>ST SCHEMES</span>
            </div>
            <div style={{ fontSize: '11px', color: 'var(--slate-medium)' }}>NFST • NOS • Post-Matric ST Schemes</div>
          </div>
        </Link>

        {/* Links */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Link 
            to="/" 
            style={{ 
              padding: '8px 14px', 
              borderRadius: '6px', 
              fontSize: '14px', 
              fontWeight: 600, 
              color: isActive('/') ? 'var(--primary-navy)' : 'var(--slate-medium)',
              backgroundColor: isActive('/') ? 'var(--primary-navy-light)' : 'transparent',
              display: 'flex', alignItems: 'center', gap: '6px'
            }}
          >
            Schemes Home
          </Link>

          <Link 
            to="/apply" 
            style={{ 
              padding: '8px 14px', 
              borderRadius: '6px', 
              fontSize: '14px', 
              fontWeight: 600, 
              color: isActive('/apply') ? 'var(--primary-navy)' : 'var(--slate-medium)',
              backgroundColor: isActive('/apply') ? 'var(--primary-navy-light)' : 'transparent',
              display: 'flex', alignItems: 'center', gap: '6px'
            }}
          >
            <FileText size={16} />
            Apply Now
          </Link>

          {user && (
            <Link 
              to="/my-applications" 
              style={{ 
                padding: '8px 14px', 
                borderRadius: '6px', 
                fontSize: '14px', 
                fontWeight: 600, 
                color: isActive('/my-applications') ? 'var(--primary-navy)' : 'var(--slate-medium)',
                backgroundColor: isActive('/my-applications') ? 'var(--primary-navy-light)' : 'transparent',
                display: 'flex', alignItems: 'center', gap: '6px'
              }}
            >
              <User size={16} />
              My Applications
            </Link>
          )}

          {user && isAdmin && (
            <Link 
              to="/admin" 
              style={{ 
                padding: '8px 14px', 
                borderRadius: '6px', 
                fontSize: '14px', 
                fontWeight: 600, 
                color: isActive('/admin') ? 'var(--saffron-amber)' : 'var(--slate-medium)',
                backgroundColor: isActive('/admin') ? 'var(--saffron-light)' : 'transparent',
                display: 'flex', alignItems: 'center', gap: '6px'
              }}
            >
              <ShieldCheck size={16} />
              Ministry Admin
            </Link>
          )}

          {/* User Auth Buttons */}
          <div style={{ marginLeft: '12px', paddingLeft: '12px', borderLeft: '1px solid var(--slate-border)', display: 'flex', gap: '8px' }}>
            {user ? (
              <button 
                onClick={logout} 
                className="btn btn-secondary btn-sm"
                title="Log out of account"
              >
                <LogOut size={14} />
                Logout
              </button>
            ) : (
              <Link to="/login" className="btn btn-primary btn-sm">
                <LogIn size={14} />
                Login
              </Link>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
}
